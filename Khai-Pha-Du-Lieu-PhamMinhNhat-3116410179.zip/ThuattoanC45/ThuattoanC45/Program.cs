﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using ThuattoanC45.hamhotro;
using ThuattoanC45.Mohinh;

namespace ThuattoanC45
{
    class Program
    {
        static void Main(string[] args)
        {
            string file = @"..\..\..\Data\";
            string filename = "test5-datanhieu.csv";
            IList<IList<string>> Data = new List<IList<string>>();
            IList<Cot> column = new List<Cot>();
            IList<string> tencolumn = null;
            var uniqueValues = new List<HashSet<string>>();

            #region Đọc file
            Console.WriteLine("Bat dau doc file");
            bool isfirstline = true;
            foreach (string line in File.ReadLines(Path.Combine(file,filename)))
            {
                if(isfirstline)
                {
                    isfirstline = false;
                    tencolumn = line.Split(',');
                    for (int i = 0; i < tencolumn.Count; i++)
                    {
                        uniqueValues.Add(new HashSet<string>());
                    }
                    continue;
                }
                Data.Add(line.Split(','));
            }
            Console.WriteLine("Ket thuc giai doan doc file");
            Console.WriteLine("----------------------------");
            #endregion

            #region Phân loại Data
            Console.WriteLine("Bat dau chia du lieu");
            IList<IList<string>> trainingdata = new List<IList<string>>();
            IList<IList<string>> datatest = new List<IList<string>>();
            int seed = 10;
            IList<IList<string>> shuffle = Shufflelist(Data, seed);
            float phantram = 0.2f;
            int testlength = (int)(Data.Count * phantram);

            for (int i = 0; i < testlength; i++) datatest.Add(shuffle[i]);
            for (int i = testlength; i < shuffle.Count; i++) trainingdata.Add(shuffle[i]);
            Console.WriteLine($"Du lieu can kiem tra : {testlength} truong hop ");
            Console.WriteLine($"Du lieu kiem tra : {shuffle.Count - testlength} truong hop ");
            Console.WriteLine("Ket thuc qua trinh chia du lieu");
            Console.WriteLine("--------------------------------");
            #endregion

            #region Xử lí Data
            Console.WriteLine("Bat dau xu li ");
            for (int i = 0; i < trainingdata.Count; i++)
            {
                for (int j = 0; j < trainingdata[i].Count; j++)
                {
                    if (trainingdata[i][j] != "?")
                        uniqueValues[j].Add(trainingdata[i][j]);
                }    
            }
            
            for (int i=0; i< tencolumn.Count;i++)
            {
                bool isnominal = false;
                foreach (string giatri in uniqueValues[i])
                {
                    if( !double.TryParse(giatri, out double giatri2))
                    {
                        isnominal = true;
                        break;
                    }    
                }
                Cot cl = new Cot(tencolumn[i], i, isnominal);
                cl.giatri = uniqueValues[i].ToList();
                column.Add(cl);
            }
            Console.WriteLine("Ket thuc qua trinh xu li");
            Console.WriteLine("-------------------------");
            #endregion

            #region Khởi tạo cây
            Console.WriteLine("Bat dau tao cay ");
            Node tree = Taocay.taocay(trainingdata, column);
            Console.WriteLine("Ket thuc qua trinh tao cay");
            Console.WriteLine("--------------------------");
            #endregion

            #region Dự đoán
            Console.WriteLine("Bat dau du doan cay");
            int doandung = 0;
            foreach (var row in datatest)
            {
                string prediction = tree.dudoan(row);
                if (prediction == row[row.Count - 1])
                    doandung++;
            }
            Console.WriteLine($"{doandung}/{datatest.Count} du doan dung");
            Console.WriteLine("Ket thuc qua trinh du doan");
            Console.WriteLine("--------------------------");
            #endregion

            Console.WriteLine("Done!!!!");
        }
        static IList<IList<string>> Shufflelist(IList<IList<string>> list, int? seed)
        {
            IList<IList<string>> kqlist = list.Select(x => x).ToList();
            Random rd = seed.HasValue ? new Random(seed.Value) : new Random();
            for (int i= kqlist.Count -1; i>0; i--)
            {
                int rdnumber = rd.Next(0, i + 1);
                IList<string> tam = kqlist[i];
                kqlist[i] = kqlist[rdnumber];
                kqlist[rdnumber] = tam;
            }
            return kqlist;
        }
    }
}