﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ThuattoanC45.Mohinh
{
    public class Node
    {
        public IDictionary<string, Node> lopcon { get; private set; }
        public double? Threshold { get; set; }
        public Cot cl { get; set; }

        public Func<IList<string>, string> dudoan;

        public Node()
        {
            lopcon = new Dictionary<string, Node>();
        }

        public void themlopcon(string name, Node con) => lopcon.Add(name, con);

        public string anticipate(IList<string> row) => dudoan(row);

        

    }
}
