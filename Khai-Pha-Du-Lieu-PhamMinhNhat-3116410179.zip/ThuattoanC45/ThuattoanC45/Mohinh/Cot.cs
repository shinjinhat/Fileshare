﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ThuattoanC45.Mohinh
{
    public class Cot
    {
        public string Ten { get; set; }
        public int Number { get; set; }
        public bool Isnominal { get; set; }
        public IList<string> giatri { get; set; }

        public Cot (string ten, int number, bool isnominal)
        {
            Ten = ten;
            Number = number;
            Isnominal = isnominal;
            giatri = new List<string>();
        }
        public Cot Clone() => (Cot)MemberwiseClone();
        public Cot DeepClone()
        {
            Cot kq = Clone();
            kq.giatri = new List<string>(giatri);
            return kq;
        }

    }
}
