﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ThuattoanC45.Mohinh;

namespace ThuattoanC45.hamhotro
{
    public class Taocay
    {
        public static Node taocay(IList<IList<string>> data, IList<Cot> cls)
        {
			Stack<TaoNode> stack = new Stack<TaoNode>();

			Node tree = new Node(); // tạo node gốc
			stack.Push(new TaoNode(data, cls, tree)); // dùng ngăn xếp để duyệt sâu 

			while (stack.Any()) // còn giá trị thì xử lí
			{
				TaoNode nc = stack.Pop(); // lấy giá trị trên cùng 
				Node node = nc.GetNode(); // trả về node hoàn chỉnh

				if (node.cl == null)
					continue; // nếu node lá quay lại while

				if (node.cl.Isnominal)
				{
					foreach (string value in node.cl.giatri) // xử lí tính lại column
					{
						Node child = new Node();
						node.themlopcon(value, child); // thêm node con vào

						var filteredDataFrom_nc = nc.dulieu.Where(row => row[node.cl.Number] == value).ToList();
						var copiedColumns = new List<Cot>(nc.Cls);
						copiedColumns.Remove(node.cl);
						var filteredColumnsFrom_nc = new List<Cot>();

						for (int i = 0; i < copiedColumns.Count; i++)
						{
							var col = copiedColumns[i];
							var values = filteredDataFrom_nc.GroupBy(row => row[col.Number]).Select(c => c.Key).ToList();
							values.Remove("?");
							if (values.Count > 1 || i == copiedColumns.Count - 1)
							{
								Cot newCol = col.Clone();
								newCol.giatri = values;
								filteredColumnsFrom_nc.Add(newCol);
							}
						} // quá trính xử lí colum

						stack.Push(new TaoNode(filteredDataFrom_nc, filteredColumnsFrom_nc, child)); // đẩy node con vào
					}
				}
				else
				{
					/*greater than threshold*/
					Node child = new Node();
					node.themlopcon(true.ToString(), child);

					var filteredDataFrom_nc = nc.dulieu.Where(row => double.Parse(row[node.cl.Number]) > node.Threshold).ToList();
					var copiedColumns = new List<Cot>(nc.Cls);
					copiedColumns.Remove(node.cl);
					var filteredColumnsFrom_nc = new List<Cot>();

					for (int i = 0; i < copiedColumns.Count; i++)
					{
						var col = copiedColumns[i];
						var values = filteredDataFrom_nc.GroupBy(row => row[col.Number]).Select(c => c.Key).ToList();
						values.Remove("?");
						if (values.Count > 1 || i == copiedColumns.Count - 1)
						{
							Cot newCol = col.Clone();
							newCol.giatri = values;
							filteredColumnsFrom_nc.Add(newCol);
						}
					}

					stack.Push(new TaoNode(filteredDataFrom_nc, filteredColumnsFrom_nc, child));

					/*lesser or equal to threshold*/
					child = new Node();
					node.themlopcon(false.ToString(), child);

					filteredDataFrom_nc = nc.dulieu.Where(row => double.Parse(row[node.cl.Number]) <= node.Threshold).ToList();
					filteredColumnsFrom_nc = new List<Cot>();

					for (int i = 0; i < copiedColumns.Count; i++)
					{
						var col = copiedColumns[i];
						var values = filteredDataFrom_nc.GroupBy(row => row[col.Number]).Select(c => c.Key).ToList();
						values.Remove("?");
						if (values.Count > 1 || i == copiedColumns.Count - 1)
						{
							Cot newCol = col.Clone();
							newCol.giatri = values;
							filteredColumnsFrom_nc.Add(newCol);
						}
					}

					stack.Push(new TaoNode(filteredDataFrom_nc, filteredColumnsFrom_nc, child));
				} // thêm node con
			}

			return tree;
		}
    }
}
