﻿using System;
using System.Collections.Generic;
using System.Text;
using ThuattoanC45.Mohinh;

namespace ThuattoanC45.hamhotro
{
    public class TinhC45 // hỗ trợ tính công thức C4.5
	{
        private IEnumerable<IList<string>> dulieu;

        public IEnumerable<IList<string>> Dulieu
        {
            get => dulieu;
            private set
            {
                if(value==null)
                {
                    dulieu = value;
                }
                else if ( dulieu==null || dulieu != value)
                {
                    dulieu = value;
					recalculateDecisionRates();
					Threshold = null;
					cl = null;
					columnRates.Clear();
					clRatesVals.Clear();
                }    
            }
        }

        public Cot Decisioncot { get; private set; }

		private IDictionary<string, double> decisionRates;

		private IDictionary<string, double> columnRates;

		private IDictionary<string, IDictionary<string, double>> clRatesVals;

		private string threshold;
		public string Threshold
		{
			get => threshold;
			set
			{
				if (value == null)
				{
					threshold = value;
				}
				else if (threshold == null || threshold != value)
				{
					threshold = value;
					if (!cl.Isnominal)
						recalculateColumnRates();
				}

			}
		}
		private Cot cl;
		public Cot Cl
		{
			get => cl;
			set
			{
				if (value == null)
				{
					cl = value;
				}
				else if (cl == null || cl.Number != value.Number)
				{
					cl = value;
					recalculateColumnRates();
				}
			}
		}

		private void setColumnAndThreshold(Cot newColumn, string newThreshold)
		{
			bool recalculate = false;
			if (newColumn != null)
			{
				if (newColumn != Cl)
					recalculate = true;
			}
			if (newThreshold != null)
			{
				if (newThreshold != Threshold)
					recalculate = true;
			}

			cl = newColumn;
			threshold = newThreshold;
			if (recalculate)
				recalculateColumnRates();
		}

		private void recalculateDecisionRates()
		{
			decisionRates.Clear();

			//initialize decision count
			foreach (string val in Decisioncot.giatri)
			{
				decisionRates.Add(val, 0);
			}

			//counts decisions
			int dataLength = 0;
			foreach (IList<string> row in Dulieu)
			{
				if (row[Decisioncot.Number] != "?")
					decisionRates[row[Decisioncot.Number]]++;
				dataLength++;
			}

			//calculates rates of decisions
			foreach (string val in Decisioncot.giatri)
			{
				decisionRates[val] = decisionRates[val] / dataLength;
			}
		}

		private void recalculateColumnRates()
		{
			columnRates.Clear();
			clRatesVals.Clear();

			if (Cl == null)
				return;

			if (Cl.Isnominal)
			{
				#region columnRates
				//initialize decision count
				foreach (string val in Cl.giatri)
				{
					columnRates.Add(val, 0);
				}

				//counts decisions
				int dataLength = 0;
				foreach (IList<string> row in Dulieu)
				{
					if (row[Cl.Number] != "?")
						columnRates[row[Cl.Number]]++;
					dataLength++;
				}

				//calculates rates of decisions
				foreach (string val in Cl.giatri)
				{
					columnRates[val] = columnRates[val] / dataLength;
				}
				#endregion

				#region columnRatesForVals
				foreach (string val in Cl.giatri)
				{
					//initialize decision count
					IDictionary<string, double> dRates = new Dictionary<string, double>();
					foreach (string dVal in Decisioncot.giatri)
					{
						dRates.Add(dVal, 0);
					}

					//counts decisions
					dataLength = 0;
					foreach (IList<string> row in Dulieu)
					{
						if (row[Cl.Number] == val)
						{
							dRates[row[Decisioncot.Number]]++;
							dataLength++;
						}
					}

					//calculates rates of decisions
					foreach (string dVal in Decisioncot.giatri)
					{
						dRates[dVal] = dRates[dVal] / dataLength;
					}

					clRatesVals.Add(val, dRates);
				}
				#endregion
			}
			else if (threshold != null)
			{
				double parsedThreshold = double.Parse(Threshold);

				#region columnRates
				//initialize decision count
				columnRates.Add(true.ToString(), 0);
				columnRates.Add(false.ToString(), 0);

				//counts decisions
				int dataLength = 0;
				foreach (IList<string> row in Dulieu)
				{
					if (row[Cl.Number] != "?")
					{
						if (double.Parse(row[Cl.Number]) > parsedThreshold)
							columnRates[true.ToString()]++;
						else columnRates[false.ToString()]++;
					}

					dataLength++;
				}

				//calculates rates of decisions
				columnRates[true.ToString()] = columnRates[true.ToString()] / dataLength;
				columnRates[false.ToString()] = columnRates[false.ToString()] / dataLength;
				#endregion

				#region columnRatesForVals
				//initialize decision count
				IDictionary<string, double> gt_dRates = new Dictionary<string, double>();
				IDictionary<string, double> loet_dRates = new Dictionary<string, double>();
				foreach (string dVal in Decisioncot.giatri)
				{
					gt_dRates.Add(dVal, 0);
					loet_dRates.Add(dVal, 0);
				}

				//counts decisions
				int gt_dataLength = 0;
				int loet_dataLength = 0;
				foreach (IList<string> row in Dulieu)
				{
					if (double.Parse(row[Cl.Number]) > parsedThreshold)
					{
						if (row[Decisioncot.Number] != "?")
							gt_dRates[row[Decisioncot.Number]]++;
						gt_dataLength++;
					}
					else
					{
						if (row[Decisioncot.Number] != "?")
							loet_dRates[row[Decisioncot.Number]]++;
						loet_dataLength++;
					}
				}

				//calculates rates of decisions
				foreach (string dVal in Decisioncot.giatri)
				{
					gt_dRates[dVal] = gt_dRates[dVal] / gt_dataLength;
					loet_dRates[dVal] = loet_dRates[dVal] / loet_dataLength;
				}

				clRatesVals.Add(true.ToString(), gt_dRates);
				clRatesVals.Add(false.ToString(), loet_dRates);
				#endregion
			}
		}

		public TinhC45(IEnumerable<IList<string>> data, Cot decisionColumn)
		{
			Decisioncot = decisionColumn;
			decisionRates = new Dictionary<string, double>();
			columnRates = new Dictionary<string, double>();
			clRatesVals = new Dictionary<string, IDictionary<string, double>>();
			Dulieu = data;
		} // hàm khởi tạo

		public double GetEntropy()
		{
			double result = 0d;
			foreach (string val in Decisioncot.giatri)
			{
				double p = decisionRates[val];
				if (p != 0 && p != 1)
					result += -p * Math.Log2(p);
			}
			return result;
		} // tính entropy decision

		public double GetEntropy(Cot column, string value)
		{
			Cl = column;
			double result = 0d;
			foreach (string val in Decisioncot.giatri)
			{
				double p = clRatesVals[value][val];
				if (p != 0 && p != 1)
					result += -p * Math.Log2(p);
			}
			return result;
		} // tính entropy của wind= weak thuộc tính rời rạc

		public double GetEntropy(Cot column, string thresholdValue, bool isGreaterThan)//continuous attribute
		{
			setColumnAndThreshold(column, thresholdValue);
			double result = 0d;
			foreach (string val in Decisioncot.giatri)
			{
				double p = clRatesVals[isGreaterThan.ToString()][val];
				if (p != 0 && p != 1)
					result += -p * Math.Log2(p);
			}
			return result;
		} // tính entropy lớn hơn, nhỏ, bằng thuộc tính liên tục

		public double GetInfoGain(Cot column)
		{
			Cl = column;
			double result = GetEntropy();
			foreach (string val in column.giatri)
			{
				double p = columnRates[val];
				result += -p * GetEntropy(column, val);
			}
			return result;
		} // tính thuộc tính rời rạc

		public double GetInfoGain(Cot column, string thresholdValue)//continuous attribute
		{
			setColumnAndThreshold(column, thresholdValue);

			double result = GetEntropy();

			double gt_p = columnRates[true.ToString()];
			double loet_p = columnRates[false.ToString()];
			result += -gt_p * GetEntropy(column, thresholdValue, true);
			result += -loet_p * GetEntropy(column, thresholdValue, false);

			return result;
		} // tính thuộc tính liên tục

		public double GetSplitInfo(Cot column)
		{
			Cl = column;
			double result = 0d;

			foreach (string val in column.giatri)
			{
				double p = columnRates[val];
				if (p != 0 && p != 1)
					result += -p * Math.Log2(p);
			}

			return result;
		}

		public double GetSplitInfo(Cot column, string thresholdValue)//continuous attribute
		{
			setColumnAndThreshold(column, thresholdValue);
			double result = 0d;

			double gt_p = columnRates[true.ToString()];
			double loet_p = columnRates[false.ToString()];

			if (gt_p != 0 && gt_p != 1)
				result += -gt_p * Math.Log2(gt_p);
			if (loet_p != 0 && loet_p != 1)
				result += -loet_p * Math.Log2(loet_p);

			return result;
		}

		public double GetGainRatio(Cot column)
		{
			//Column = column;
			return GetInfoGain(column) / GetSplitInfo(column);
		}

		public double GetGainRatio(Cot column, string thresholdValue)//continuous attribute
		{
			//setColumnAndThreshold(column, thresholdValue);
			return GetInfoGain(column, thresholdValue) / GetSplitInfo(column, thresholdValue);
		}
	}
}
