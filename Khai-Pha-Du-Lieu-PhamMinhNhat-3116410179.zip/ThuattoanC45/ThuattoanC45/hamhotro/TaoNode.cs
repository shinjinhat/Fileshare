﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ThuattoanC45.Mohinh;

namespace ThuattoanC45.hamhotro
{
    public class TaoNode
    {
        public IList<IList<string>> dulieu { get; private set; }

        public IList<Cot> Cls { get; private set; } // mảng cl , chứa thông tin của những cột của data con 

		private Node node; //node trả về

		private TinhC45 thuattoan; // gọi lại sử dụng

		public TaoNode(IList<IList<string>> data, IList<Cot> cls) : this(data, cls, new Node())
		{ } // hàm khởi tạo

		public TaoNode(IList<IList<string>> data, IList<Cot> cls, Node node)
		{
			this.dulieu = data;
			this.Cls = cls;
			this.node = node;
			thuattoan = new TinhC45(data, cls.Last());
		} // hàm khởi tạo

		private ColumnWrapper getBranchingColumn()
		{
			if (Cls.Last().giatri.Count < 2)//formulas.GetEntropy() == 0
				return new ColumnWrapper(null);

			double gainRatio = double.MinValue;
			double? threshold = null;
			Cot result = null;

			IList<Cot> newCols = new List<Cot>(Cls);
			for (int j = 0; j < Cls.Count - 1; j++)
			{
				//remove columns have 1 value
				Cot col = Cls[j];
				if (col.giatri.Count < 2)
				{
					newCols.Remove(col);
				}
				//calculate gain ratio
				else if (col.Isnominal)
				{
					double gR = thuattoan.GetGainRatio(col);
					if (gR > gainRatio)
					{
						gainRatio = gR;
						threshold = null;
						result = col;
					}
				}
				else
				{
					col.giatri = col.giatri.OrderBy(v => v).ToList();
					for (int i = 0; i < col.giatri.Count - 1; i++)
					{
						double th = double.Parse(col.giatri[i]);
						double gR = thuattoan.GetGainRatio(col, col.giatri[i]);
						if (gR > gainRatio)
						{
							gainRatio = gR;
							threshold = th;
							result = col;
						}
					}
				}
			}
			Cls = newCols;

			return new ColumnWrapper(result, threshold);
		} // tính gainratio để dùng cột quyết định rẽ nhánh

		public Node GetNode()
		{
			if (node == null)
				node = new Node();

			ColumnWrapper cw = getBranchingColumn(); // rẽ nhánh ở cột nào

			node.cl = cw.Column;
			node.Threshold = cw.Threshold;

			if (node.cl != null)
			{
				if (node.cl.Isnominal) 
				{
					IDictionary<string, int> count = new Dictionary<string, int>();
					Cot decisionColumn = Cls.Last();
					foreach (string val in decisionColumn.giatri)
					{
						count.Add(val, 0);
					}

					foreach (IList<string> row in dulieu)
					{
						count[row[decisionColumn.Number]]++;
					}

					string mostAppearResult = count.First().Key;

					foreach (string val in decisionColumn.giatri)
					{
						if (count[val] > count[mostAppearResult])
							mostAppearResult = val;
					}

					node.dudoan = row => node.lopcon.ContainsKey(row[node.cl.Number]) ? // gán hàm quyết định cho node
						node.lopcon[row[node.cl.Number]].anticipate(row) :
						mostAppearResult;
				}
				else
				{
					node.dudoan = row => double.Parse(row[node.cl.Number]) > node.Threshold ?  // hàm quyết định cho node
						node.lopcon[true.ToString()].anticipate(row) :
						node.lopcon[false.ToString()].anticipate(row);
				}
			}
			else // không còn cột để rẽ nhánh
			{
				IDictionary<string, int> count = new Dictionary<string, int>();
				Cot decisionColumn = Cls.Last();
				foreach (string val in decisionColumn.giatri)
				{
					count.Add(val, 0);
				}

				foreach (IList<string> row in dulieu)
				{
					count[row[decisionColumn.Number]]++;
				}

				string mostAppearResult = count.First().Key;

				foreach (string val in decisionColumn.giatri)
				{
					if (count[val] > count[mostAppearResult])
						mostAppearResult = val;
				}

				node.dudoan = row => mostAppearResult; // gán bằng giá trị xuất hiện nhiều nhất
			}

			return node;
		} // trả về node

		private class ColumnWrapper
		{
			public Cot Column { get; set; }
			public double? Threshold { get; set; }

			public ColumnWrapper(Cot column)
			{
				Column = column;
			}

			public ColumnWrapper(Cot column, double? threshold) : this(column)
			{
				Threshold = threshold;
			}
		}
	}
}
